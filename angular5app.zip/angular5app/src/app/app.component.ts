import { Component } from '@angular/core';

import {
  UnicoCheckBuilder,
  SelfieCameraTypes,
  DocumentCameraTypes,
  MainView,
  UnicoThemeBuilder
} from "unico-webframe";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'poc-check-angular';

  unicoCamera: any;

  callback = {
    on: {
      success: function (obj: any) {
        window.alert(JSON.stringify(obj));
      },
      error: function (error: any) {
        window.console.log(error);
        window.alert(`
            Câmera fechada
            ------------------------------------
            Motivo: ${error.code} - ${error.message} ${JSON.stringify(error.stack)}
          `);
      },
      support: function (error: any) {
        console.log(error);
        window.alert(`
            Browser não suportado
            ------------------------------------
            iOS: Safari
            Android/Windows: Chrome, Firefox
          `);
      }
    }
  };

  ngOnInit() {
    function getHostUrlBase(path: any) {
      return window.location.protocol + "//" + window.location.host + "/" + path;
    }

    const urlPathModels = getHostUrlBase("assets/models");

    const unicoTheme = new UnicoThemeBuilder()
      .setColorSilhouetteSuccess("#0384fc")
      .setColorSilhouetteError("#D50000")
      .setColorSilhouetteNeutral("#fcfcfc")
      .setBackgroundColor("#dff1f5")
      .setColorText("#0384fc")
      .setBackgroundColorComponents("#0384fc")
      .setColorTextComponents("#dff1f5")
      .setBackgroundColorButtons("#0384fc")
      .setColorTextButtons("#dff1f5")
      .setBackgroundColorBoxMessage("#fff")
      .setColorTextBoxMessage("#000")
      .setHtmlPopupLoading(`<div style="position: absolute; top: 45%; right: 50%; transform: translate(50%, -50%); z-index: 10; text-align: center;">Carregandooooo...</div>`)
      .build();

    const unicoCameraBuilder = new UnicoCheckBuilder();
    unicoCameraBuilder.setTheme(unicoTheme)
    unicoCameraBuilder.setModelsPath(urlPathModels);
    unicoCameraBuilder.setResourceDirectory("/assets/resources");

    this.unicoCamera = unicoCameraBuilder.build();
  }

  async openCamera() {
    const { open } = await this.unicoCamera.prepareSelfieCamera(
      '/assets/services.json',
      SelfieCameraTypes.NORMAL
    );

    open(this.callback);
  }
}
